该模块依赖于`Rabc模块`中的`Role模块`。

如果只使用该模块，需要自行删除编辑页面中的选择角色部分

### enumdata.js 文件添加

```js
class enumdata {
  ...
  static user_state = {
    1: '正常',
    2: '禁止登录',
    3: '账号异常',
  };
}
```

### routes.js 文件添加

如果你使用约定式路由，则忽略以下部分

```js
import PageRabcUserCreate from '@/pages/Rabc/User/create';
import PageRabcUserDetail$id from '@/pages/Rabc/User/detail/$id';
import PageRabcUserUpdate$id from '@/pages/Rabc/User/update/$id';
import PageRabcUser from '@/pages/Rabc/User';

const routerConfig = [
  ...
  {
    path: '/rabc/user',
    exact: false,
    component: BasicLayout,
    children: [
      {
        path: '/create',
        exact: true,
        component: PageRabcUserCreate,
      },
      {
        path: '/detail/:id',
        exact: true,
        component: PageRabcUserDetail$id,
      },
      {
        path: '/update/:id',
        exact: true,
        component: PageRabcUserUpdate$id,
      },
      {
        path: '',
        exact: true,
        component: PageRabcUser,
      },
    ],
  },
]
```
