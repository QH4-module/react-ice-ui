import React from 'react';
import { Box, Form, Typography, Avatar, Tag, Card } from '@alifd/next';
import styles from './detail.module.scss';
import YunReact from '@/utils/YunReact';
import moment from 'moment';
import _ from 'lodash';

const EmptyText = function (props) {
  if (!props.value && props.value !== 0) {
    return <span style={{ color: '#999999' }}>未设置</span>;
  } else {
    if (!_.isArray(props.value)) {
      return props.value;
    } else {
      for (let i = 0; i < props.value.length; i++) {
        if (props.value[i] || props.value[i] === 0) {
          return props.value[i];
        }
      }
      return <span style={{ color: '#999999' }}>未设置</span>;
    }
  }
};

export default function DetailContent(props) {

  return (
    <div>
      <Card free className={styles.AdvancedDetailHead}>
        <Box spacing={10}>
          <Box direction="row" spacing={10}>
            <Avatar icon={'account'} size="large" src={YunReact.image(props.data.avatar, 80, 80)} />
            <Box flex={1} spacing={15}>
              <Box direction="row" justify="space-between">
                <Box>
                  <Typography.Text className={styles.TitleName}>
                    {<EmptyText value={[props.data.nick_name, props.data.account]} />}
                  </Typography.Text>
                  <Typography.Text className={styles.TitleInfo}>
                    {props.data.mobile ? props.data.mobile : '未绑定手机'}
                    {props.data.email && '|'}
                    {props.data.email}
                  </Typography.Text>
                </Box>
              </Box>
              <Form labelAlign="top" responsive className={styles.DetailHeaderForm}>
                <Form.Item colSpan={3} label="用户ID">
                  <span className="next-form-preview">{props.data.id}</span>
                </Form.Item>
                <Form.Item colSpan={9} label="备注信息">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.description]} />
                  </span>
                </Form.Item>
              </Form>
            </Box>
          </Box>
        </Box>
      </Card>
      <Box spacing={20}>
        <Card free>
          <Card.Header title="基础信息" />
          <Card.Divider />
          <Card.Content>
            <div className={styles.Content}>
              <Form labelAlign="top" responsive>
                <Form.Item colSpan={3} label="名字">
                  <span className="next-form-preview">{props.data.nick_name}</span>
                </Form.Item>
                <Form.Item colSpan={3} label="性别">
                  <span className="next-form-preview">
                    {props.data.gender === 1 ? '男' : props.data.gender === 2 ? '女' : <EmptyText />}
                  </span>
                </Form.Item>
                <Form.Item colSpan={3} label="生日">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.birthday]} />
                  </span>
                </Form.Item>
                <Form.Item colSpan={3} label="地区">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.city_name]} />
                  </span>
                </Form.Item>
              </Form>
            </div>
          </Card.Content>
        </Card>

        <Card free>
          <Card.Header title="账号信息" />
          <Card.Divider />
          <Card.Content>
            <div className={styles.Content}>
              <Form labelAlign="top" responsive>
                <Form.Item colSpan={4} label="账号">
                  <span className="next-form-preview">
                    {<EmptyText value={[props.data.account]} />}
                  </span>
                </Form.Item>
                <Form.Item colSpan={4} label="手机号">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.mobile]} />
                  </span>
                </Form.Item>
                <Form.Item colSpan={4} label="邮箱">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.email]} />
                  </span>
                </Form.Item>
                <Form.Item colSpan={4} label="创建时间">
                  <span className="next-form-preview">{moment.unix(props.data.create_time)
                    .format('YYYY-MM-DD HH:mm:ss')}
                  </span>
                </Form.Item>
                <Form.Item colSpan={8} label="创建者">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.create_by_name, props.data.create_by]} />
                  </span>
                </Form.Item>
                <Form.Item colSpan={4} label="微信openid">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.wechat_openid]} />
                  </span>
                </Form.Item>
                <Form.Item colSpan={4} label="微信unionid">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.wechat_unionid]} />
                  </span>
                </Form.Item>
                <Form.Item colSpan={4} label="QQ openid">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.qq_id]} />
                  </span>
                </Form.Item>
                <Form.Item colSpan={4} label="支付宝id">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.alipay_id]} />
                  </span>
                </Form.Item>
                <Form.Item colSpan={4} label="微博id">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.weibo_id]} />
                  </span>
                </Form.Item>
                <Form.Item colSpan={4} label="Apple id">
                  <span className="next-form-preview">
                    <EmptyText value={[props.data.apple_id]} />
                  </span>
                </Form.Item>
              </Form>
            </div>
          </Card.Content>
        </Card>

        <Card free showHeadDivider={false}>
          <Card.Header title="关联角色" />
          <Card.Divider />
          <Card.Content>
            {
              props.data.roles &&
              <Tag.Group>
                {
                  props.data.roles.map((item) => {
                    return <Tag type="primary" color={'orange'} key={item.id}>{item.name}</Tag>;
                  })
                }
              </Tag.Group>
            }
          </Card.Content>
        </Card>
      </Box>
    </div>
  );
};

