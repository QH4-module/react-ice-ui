该模块依赖于`Rabc模块`中的`Role模块`。

该模块只提供了列表和详情，没有提供新增。因为资源的实现，必须需要代码辅助，客户并没有办法增加。但是保留了新增的代码，只是被隐藏了

### enumdata.js 文件添加

```js
class enumdata {
  ...
  static privilege_type = {
    1: '菜单',
    2: '其它',
  };
}
```

### routes.js 文件添加

如果你使用约定式路由，则忽略以下部分

```js
import PageRabcPrivilegeUpdate$id from '@/pages/Rabc/Privilege/update/$id';
import PageRabcPrivilegeDetail$id from '@/pages/Rabc/Privilege/detail/$id';
import PageRabcPrivilege from '@/pages/Rabc/Privilege';

const routerConfig = [
  ...
    {
      path: '/rabc/privilege',
      exact: false,
      component: BasicLayout,
      children: [
        {
          path: '/detail/:id',
          exact: true,
          component: PageRabcPrivilegeDetail$id,
        },
        {
          path: '/update/:id',
          exact: true,
          component: PageRabcPrivilegeUpdate$id,
        },
        {
          path: '',
          exact: true,
          component: PageRabcPrivilege,
        },
      ],
    },
]
```
