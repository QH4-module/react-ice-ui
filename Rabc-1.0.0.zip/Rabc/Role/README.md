### routes.js 文件添加

如果你使用约定式路由，则忽略以下部分

```js
import PageRabcRoleCreate from '@/pages/Rabc/Role/create';
import PageRabcRoleUpdate$id from '@/pages/Rabc/Role/update/$id';
import PageRabcRoleDetail$id from '@/pages/Rabc/Role/detail/$id';
import PageRabcRole from '@/pages/Rabc/Role';

const routerConfig = [
  ...
    {
      path: '/rabc/role',
      exact: false,
      component: BasicLayout,
      children: [
        {
          path: '/create',
          exact: true,
          component: PageRabcRoleCreate,
        },
        {
          path: '/detail/:id',
          exact: true,
          component: PageRabcRoleDetail$id,
        },
        {
          path: '/update/:id',
          exact: true,
          component: PageRabcRoleUpdate$id,
        },
        {
          path: '',
          exact: true,
          component: PageRabcRole,
        },
      ],
    },
]
```
